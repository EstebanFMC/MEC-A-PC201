
package Clases;

abstract class Notificaciones {
    
}
