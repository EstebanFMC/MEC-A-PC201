package Clases;

public class Taquillas extends HorarioOperacional {
private double Precio;
private int NoTaquilla;
static int numeroTaquillas = 0;

public Taquillas (String HoraInicio, String HoraFinalizacion, String HoraInicioFines, String HoraFinalizacionFines, double Precio){
    super(HoraInicio, HoraFinalizacion, HoraInicioFines, HoraFinalizacionFines);
    this.Precio = Precio;
    numeroTaquillas++;
    NoTaquilla = numeroTaquillas;

}

public void MostrarPrecio(){
    System.out.println("El precio a pagar el día de hoy es de: " + Precio);
    
}

    
    
}
