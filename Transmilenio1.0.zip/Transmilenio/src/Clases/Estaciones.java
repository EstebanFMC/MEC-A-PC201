package Clases;
import java.util.ArrayList;

public class Estaciones extends HorarioOperacional{    
    private String nombre;
    private int CantidadBuses;
    private ArrayList<Taquillas> taquilla;
    private ArrayList<Buses> buses;
    String Separador = "------------------------------------------------------------------------";

    public Estaciones (String HoraInicio, String HoraFinalizacion, String HoraInicioFines, String HoraFinalizacionFines, ArrayList buses, ArrayList taquillas){
         super(HoraInicio, HoraFinalizacion, HoraInicioFines, HoraFinalizacionFines);
         taquilla = new ArrayList<>();
         this.taquilla.addAll(taquillas);
         buses = new ArrayList<>();
         this.buses.addAll(buses); //COPIADO DE TODOS LOS BUSES PASANTES POR LA ESTACION
         
    }
    
    public void MostrarBuses(){
        System.out.println(Separador);
        System.out.println("Los buses pasantes por la estacion " + nombre + " son:");
        for (Buses i : buses)
            System.out.println(i.getIdentificador());    
        
        System.out.println(Separador);
    }
    
    
    
}
