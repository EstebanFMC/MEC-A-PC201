
package Clases;

public class Notificacion {
    
}
