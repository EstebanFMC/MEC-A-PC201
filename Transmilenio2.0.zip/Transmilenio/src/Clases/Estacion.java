package Clases;
import java.util.ArrayList;

public class Estacion {    
    private String nombre;
    private String RutaPerteneciente;
    private int CantidadBuses;
    private ArrayList<Taquilla> taquilla;
    private ArrayList<Bus> buses;
    String Separador = "------------------------------------------------------------------------";//NO INCLUIR EN EL UML

    public Estacion (ArrayList buses, ArrayList taquillas, String RutaPerteneciente){
         taquilla = new ArrayList<>();
         this.taquilla.addAll(taquillas);
         buses = new ArrayList<>();
         this.buses.addAll(buses); //COPIADO DE TODOS LOS BUSES PASANTES POR LA ESTACION
         this.RutaPerteneciente = RutaPerteneciente;
         
    }
    
    public void MostrarBuses(){
        System.out.println(Separador);
        System.out.println("Los buses pasantes por la estacion " + nombre + " son:");
        for (Bus i : buses)
            System.out.println(i.getIdentificador());    
        
        System.out.println(Separador);
    }
    
    
    
}
